celcius_to_fahrenheit = lambda c: (9 / 5) * c + 32
celcius_to_reamur = lambda c: 0.8 * c

print('input c = 100', 'output = ', celcius_to_fahrenheit(100))
print('input c = 80', 'output = ', celcius_to_fahrenheit(80))
print('input c = 0', 'output = ', celcius_to_fahrenheit(0))
