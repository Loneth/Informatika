# Odilio Ganesha Nugroho - 71210739
# Grup D Soal 1

a = int(input("Masukkan suhu tubuh anda: "))

if a >= 38:
    print("Anda sedang demam")
else:
    print("anda tidak demam")
