# Odilio Ganesha Nugroho - 71210739
# Grup A Soal 2

bilangan = int(input('Masukkan suatu bilangan: '))

hasil = 'Positif' if bilangan > 0 else 'Negatif'

print('Nol' if bilangan == 0 else hasil)
