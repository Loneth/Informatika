# Odilio Ganesha Nugroho - 71210739
# Grup D Soal 2

a = int(input("Masukkan suatu bilangan: "))

if a > 0:
    print("Positif")
elif a < 0:
    print("Negatif")
else:
    print("Nol")
